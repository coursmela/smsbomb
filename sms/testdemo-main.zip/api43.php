<!DOCTYPE html>
<html lang="en">
<head>
   <title>The Website is coming Soon ....</title>
<meta charset="UTF-8">
  <meta name="description" content="Coming soon template">  
  <meta name="author" content="https://downloadfort.com/">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="CSS.css" rel="stylesheet" />	
</head>
<body class="body">
    <img src="coming-soon.jpg" class="imgcenter"/>    
    <p class="txtwhite">kindly visit after some time.&nbsp;<strong class="txtyellow"> thank you!</strong></p>
</body>
</html>